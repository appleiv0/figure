import os

THERAPY_RESULT_DIR = os.environ["THERAPY_RESULT_DIR"]
THERAPY_RESULT_TEMPLATE_PATH = os.path.join(THERAPY_RESULT_DIR, "0_template.json")
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]
