import os
import time
from datetime import datetime
import libcommon.config.status_error as status_error
from app.models.response_figure import (
    ReceiptNoRes,
    SetFigureRes,
    SetPostionRes,
    LLMCompletionRes,
    GetReportRes,
)
from libcommon.utils.chatUtils import get_josa, get_josa_en
from libcommon.utils.jsonUtils import make_json, read_json

import app.config.app_config as CFG
from app.controllers import chatbot


card_directions = {
    "강아지": "left",
    "개": "left",
    "개구리": "left",
    "고슴도치": "left",
    "공룡": "left",
    "나비": "left",
    "도마뱀": "left",
    "독수리": "right",
    "돌": "right",
    "돌고래": "left",
    "돼지": "left",
    "말": "right",
    "뱀": "left",
    "병아리": "left",
    "불곰": "right",
    "사자": "right",
    "상어": "right",
    "새끼-양": "left",
    "악어": "left",
    "알에서-나오는-병아리": "left",
    "양": "left",
    "일반-새": "left",
    "젖소": "right",
    "조개": "right",
    "캥거루": "left",
    "코끼리": "right",
    "코브라": "left",
    "토끼": "left",
    "학": "left",
    "호랑이": "right",
    "흑표범": "right",
    "새끼팬더": "left",
}


def create_receipt_number(counselor: dict, kid: dict, agree: bool):
    ## 기존 file 혹은 db 조회해서 신규 관리번호 부여하고 file 혹은 db 저장. 정상 처리되면 관리번호 반환.
    result_list = os.listdir(CFG.THERAPY_RESULT_DIR)
    if len(result_list) == 0:
        receipt_no = 1
    else:
        # result_list.sort()
        receipt_no = len(result_list)

    # josa = get_josa(kid["name"])
    josa = get_josa_en(kid["name"])

    new_json = read_json(CFG.THERAPY_RESULT_TEMPLATE_PATH)

    new_json["date"] = datetime.strftime(datetime.now(), format="%Y%m%d%H%M%S")
    new_json["receiptNo"] = receipt_no
    new_json["counselor"] = counselor
    new_json["kid"] = kid
    new_json["kid"].update(josa)
    new_json["agree"] = agree

    make_json(os.path.join(CFG.THERAPY_RESULT_DIR, f"{receipt_no}_{kid['name']}.json"), new_json)

    return status_error.OK, ReceiptNoRes(receiptNo=receipt_no, endWord=josa)


def set_figure(kidName: str, receiptNo: int, stage: str, figures: list):
    data_json_path = os.path.join(CFG.THERAPY_RESULT_DIR, f"{receiptNo}_{kidName}.json")

    data_json = read_json(data_json_path)

    if stage in ["3", "5", "6"]:
        family_list = [x["relation"] for x in data_json["figures"][stage]]
        for figure in figures:
            if figure["relation"] in family_list:
                idx = family_list.index(figure["relation"])
                data_json["figures"][stage][idx] = figure
            else:
                data_json["figures"][stage].append(figure)
    else:
        data_json["figures"][stage] = figures

    make_json(data_json_path, data_json)
    score, message = chatbot.get_score(kidName, receiptNo)

    return status_error.OK, SetFigureRes(score=score)


def set_position(kidName: str, receiptNo: int, centerH: int, centerV: int, figures: list):
    data_json_path = os.path.join(CFG.THERAPY_RESULT_DIR, f"{receiptNo}_{kidName}.json")

    data_json = read_json(data_json_path)
    data_json["positions"]["centerH"] = centerH
    data_json["positions"]["centerV"] = centerV
    data_json["positions"]["figures"] = figures

    for i, card in enumerate(data_json["positions"]["figures"]):
        if card["figure"] in card_directions.keys():
            if card["direction"] == 0:
                data_json["positions"]["figures"][i]["direction"] = card_directions[card["figure"]]
            else:
                if card_directions[card["figure"]] == "right":
                    data_json["positions"]["figures"][i]["direction"] = "left"
                else:
                    data_json["positions"]["figures"][i]["direction"] = "right"
        else:
            data_json["positions"]["figures"][i]["direction"] = "left"

    make_json(data_json_path, data_json)

    score, message = chatbot.get_score(kidName, receiptNo)

    return status_error.OK, SetPostionRes(score=score, message=message)


def llm_completion(kidName: str, receiptNo: int, count: int, relation: str, message: str):
    ## 이름과 관리번호로 기존 정보 file 혹은 db조회. 질의 응답 저장.
    ## 응답에 따라 prompt engineering을 진행, chatgpt 호출 및 학대 정황 파싱
    ## 이름과 관리번호가 없을 경우 error
    data_json_path = os.path.join(CFG.THERAPY_RESULT_DIR, f"{receiptNo}_{kidName}.json")
    data_json = read_json(data_json_path)

    if relation not in data_json["llmCompletion"].keys():
        data_json["llmCompletion"][relation] = {"bot": ["", ""], "user": ["", ""]}
        data_json["abuser"][relation] = 0
        make_json(data_json_path, data_json)

    if count > 0:
        data_json["llmCompletion"][relation]["user"][count - 1] = message
        make_json(data_json_path, data_json)

    ## prompt engineering
    ## 수정필요 =======================
    completion = chatbot.get_llm_completion(kidName, receiptNo, count, relation)
    ## 수정필요 =======================

    return status_error.OK, LLMCompletionRes(message=completion)


def get_Report(kidName: str, receiptNo: int):
    score, _ = chatbot.get_score(kidName, receiptNo)
    message, data_json = chatbot.get_report(kidName, receiptNo)
    return status_error.OK, GetReportRes(score=score, message=message, result=data_json)
