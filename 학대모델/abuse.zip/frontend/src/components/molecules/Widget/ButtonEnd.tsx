import { useNavigate } from "react-router-dom";
import { USER } from "../../../constants/common.constant";
import { useGetReport } from "../../../services/hooks/hookChatbot";
import { getItemLocalStorage } from "../../../utils/helper";
import Icon from "../../atoms/Icon";
import useStore from "../../../store";

const ButtonEnd = () => {
  const { fetchReport } = useGetReport();
  const userInfo = getItemLocalStorage(USER);
  const navigator = useNavigate();
  const setResponse = useStore((state: any) => state.setResponse);
  const response = useStore((state: any) => state.response);

  const handleReport = async () => {
    try {
      const response = await fetchReport({
        kidName: userInfo.kidname,
        receiptNo: `${userInfo.receiptNo}`,
      });

      if (!response) {
        console.error("API Error:", response.statusText);
      }

      navigator("/result");
      setResponse(response);
      return response;
    } catch (error: any) {
      console.error("Error:", error.message);
    }
  };

  const handleNext = () => {
    navigator("/ending");
  };

  const handleDownload = () => {
    const jsonData = response.result;

    const jsonStr = JSON.stringify(jsonData, null, 2);

    const blob = new Blob([jsonStr], { type: "application/json" });

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "data.json";

    document.body.appendChild(a);
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="react-chatbot-kit-chat-bot-message-container flex gap-2">
        {location.pathname === "/stage6" && (
          <button
            className="text-2xl font-bold ml-auto flex items-center gap-2 border border-primary bg-primary hover:bg-grey-100 hover:text-[#2C9608] text-white px-3 py-4 rounded-md"
            onClick={() => handleNext()}
          >
            인터뷰 종료
            <Icon
              icon="arrowRight"
              width={24}
              height={24}
              className="max-w-6"
            />
          </button>
        )}
        {location.pathname === "/ending" && (
          <button
            className="text-2xl font-bold ml-auto flex items-center gap-2 border border-primary bg-primary hover:bg-grey-100 hover:text-[#2C9608] text-white px-3 py-4 rounded-md"
            onClick={() => handleReport()}
          >
            결과 페이지로 이동
            <Icon
              icon="arrowRight"
              width={24}
              height={24}
              className="max-w-6"
            />
          </button>
        )}
        {location.pathname === "/result" && (
          <button
            className="text-2xl font-bold ml-auto flex items-center gap-2 border border-primary bg-primary hover:bg-grey-100 hover:text-[#2C9608] text-white px-3 py-4 rounded-md"
            onClick={() => handleDownload()}
          >
            {/* JSON 데이터 로드 */}
            상담 결과 다운로드
            <Icon icon="download" width={24} height={24} className="max-w-6" />
          </button>
        )}
      </div>
    </>
  );
};

export default ButtonEnd;
