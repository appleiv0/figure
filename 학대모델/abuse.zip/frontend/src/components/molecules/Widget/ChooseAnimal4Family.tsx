import { useState } from "react";
import Icon from "../../atoms/Icon";
import Modal from "../../atoms/Modal";
import useStore from "../../../store";
import { Animal } from "../../../data";
import { useLocation } from "react-router-dom";

const ChooseAnimal4Family = (props: any) => {
  const selectedCards = useStore((state: any) => state.selectedCards);
  const setSelectedCards = useStore((state: any) => state.setSelectedCards);
  const selectedFamily = useStore((state: any) => state.selectedFamily);
  const currentIndex = useStore((state: any) => state.currentIndex);
  const selectedCardsNew = useStore((state: any) => state.selectedCardsNew);
  const setSelectedCardsNew = useStore(
    (state: any) => state.setSelectedCardsNew
  );
  const selectedCardsNew6 = useStore((state: any) => state.selectedCardsNew6);
  const setSelectedCardsNew6 = useStore(
    (state: any) => state.setSelectedCardsNew6
  );

  const [currentFigure, setCurrentFigure] = useState<any>();
  const location = useLocation();
  const [isShow, setIsShow] = useState<boolean>(false);
  const openModal = () => {
    setIsShow(!isShow);
  };

  const [checkedState, setCheckedState] = useState(() =>
    Animal.map(() => false)
  );

  const handleCircleClick = (index: number, name: string, img: string, josa: number) => {
    setCheckedState(checkedState.map((_bool, j) => j === index));
    setCurrentFigure({
      figure: name,
      index,
      img,
      josa,
      relation: selectedFamily[currentIndex],
    });
  };
  const initialAction = () => {
    if (location.pathname === "/stage3") {
      props.actions.initialAction([...selectedCards, currentFigure]);
      setSelectedCards([...selectedCards, currentFigure]);
    } else if (location.pathname === "/stage5") {
      props.actions.initialAction5([...selectedCardsNew, currentFigure]);
      setSelectedCardsNew([...selectedCardsNew, currentFigure]);
    } else if (location.pathname === "/stage6") {
      props.actions.initialAction6([...selectedCardsNew6, currentFigure]);
      setSelectedCardsNew6([...selectedCardsNew6, currentFigure]);
    }
    setIsShow(false);
  };

  return (
    <>
      <div className="react-chatbot-kit-chat-bot-message-container flex gap-2">
        <button
          className="text-2xl font-bold ml-auto flex gap-2 items-center border border-primary bg-primary hover:bg-grey-100 hover:text-greenDark text-white px-3 py-4 rounded-md"
          onClick={() => openModal()}
        >
          동물 선택하러 가기
          <Icon icon="arrowRight" width={24} height={24} className="max-w-6" />
        </button>
      </div>
      <Modal
        isShowing={isShow}
        hide={openModal}
        children={
          <div className="background-container">
            <div className="w-full mx-auto grid grid-cols-12 px-5 py-4">
              <div className="grid grid-cols-8 col-span-12 gap-1">
                {Animal.map((animal) => {
                  return (
                    <div key={animal.index} className={`animal-card`}>
                      <button
                        className={`animal-card-content h-full rounded-xl p-3 text-center ${
                          checkedState[animal.index]
                            ? "bg-primary text-white"
                            : "bg-white text-black"
                        }`}
                        onClick={() =>
                          handleCircleClick(
                            animal.index,
                            animal.name,
                            animal.img,
                            animal.josa
                          )
                        }
                      >
                        <img src={animal.img} alt={animal.name} />
                        <span className="text-sm font-bold">{animal.name}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="col-span-1 z-20 text-center font-bold relative">
                <button
                  className="fixed text-xs border border-primary bg-primary text-white h-[6rem] px-5 py-4 mt-4 rounded-full right-0 bottom-[-8rem]"
                  onClick={() => initialAction()}
                >
                  <Icon
                    icon="check"
                    width={20}
                    height={20}
                    className="max-w-5 mx-auto"
                  />
                  선택 완료
                </button>
              </div>
            </div>
          </div>
        }
      />
    </>
  );
};

export default ChooseAnimal4Family;
