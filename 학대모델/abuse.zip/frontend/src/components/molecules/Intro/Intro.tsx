import { ReactNode } from "react";
import { Animal } from "../../../data";
import Icon from "../../atoms/Icon";

type IntroTypes = {
  children: ReactNode;
  handleChooseAnimal: () => void;
};

const Intro = ({ children, handleChooseAnimal }: IntroTypes) => {
  const filteredAnimalsIntro = Animal.filter(
    (animal) => animal.index >= 0 && animal.index <= 5
  );

  return (
    <div className="container-md mx-auto">
      <img
        className="w-[4.5rem] flex justify-center  mx-auto items-center mt-[2rem] "
        src="/assets/images/01.png"
      />
      <h1 className="text-center text-3xl font-extrabold mt-8 mb-10">
        [ 진행 방법 ]
      </h1>
      <div className="text-center text-2xl leading-9 font-bold mb-10 max-w-[39rem] mx-auto">
        {children}
      </div>
      {/* <div className="background-container">
        <div className="animal-cards-container grid grid-cols-6 gap-3 justify-center text-center">
          {filteredAnimalsIntro.map((animal) => (
            <div key={animal.index} className="animal-card">
              <div className="animal-card-content w-full bg-white rounded-xl p-3">
                <img
                  src={animal.img}
                  alt={animal.name}
                  className="animal-image w-32 mx-auto object-contain mb-2"
                />
                <span className="animal-name xl:text-xl font-bold">
                  {animal.name}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div> */}

      <div className="w-full  z-20 text-center font-bold mt-10">
        <button
          className="flex flex-col gap-1 items-center justify-center text-[0.9375rem] mx-auto mt-4 border border-primary w-[5.75rem] h-[5.75rem] bg-primary hover:bg-grey-100 hover:text-greenDark text-white px-5 py-4 rounded-full"
          onClick={handleChooseAnimal}
        >
          <Icon icon="check" width={20} height={20} className="max-w-5" />
          확인
        </button>
      </div>
    </div>
  );
};

export default Intro;
