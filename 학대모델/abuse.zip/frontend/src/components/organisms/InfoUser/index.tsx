import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { USER } from "../../../constants/common.constant";
import { useCreatReceipt } from "../../../services/hooks/hookAuth";
import {
  removeItemLocalStorage,
  setItemLocalStorage,
} from "../../../utils/helper";
import SubmitButton from "../../atoms/Form/Button/SubmitButton";
import DateInput from "../../atoms/Form/DateInput";
import FormLayout from "../../atoms/Form/FormLayout";
import TextField from "../../atoms/Form/InputField/TextField";

interface AuthInterface {
  kidname: string;
  gender: "Male" | "Female" | null;
  counselor: string;
  name_counselor: string;
  selectedDate: Date | any;
}

const InforUser: React.FC = () => {
  const [, setSelectedDate] = useState<Date | null>(new Date());
  const [selectedDatecolor, setSelectedDatecolor] = useState<string | null>(
    null
  );
  const navigator = useNavigate();
  const { fetchReceipt } = useCreatReceipt();

  const form = useForm<AuthInterface>({
    defaultValues: {
      kidname: "",
      gender: null,
      counselor: "",
      name_counselor: "",
      selectedDate: null,
    },
  });

  const formWatch = form.watch();
  const checkDisable =
    !formWatch.kidname ||
    !formWatch.gender ||
    !formWatch.counselor ||
    !formWatch.name_counselor ||
    !formWatch.selectedDate;

  const handleChangeDateFilter = (date: Date) => {
    setSelectedDate(date);
    form.setValue("selectedDate", date);
    setSelectedDatecolor("Green");
  };

  const handleClear = () => {
    form.reset();
    setSelectedDate(new Date());
  };

  const handleRegister = async () => {
    const formData = form.getValues();
    const birthDate = formData.selectedDate
      ? dayjs(formData.selectedDate, "yyyyMMdd")
      : "";
    try {
      const response = await fetchReceipt({
        counselor: {
          name: formData.name_counselor,
          organization: formData.counselor,
        },
        kid: {
          birth: birthDate,
          name: formData.kidname,
          sex: formData.gender,
        },
        agree: true,
      });

      if (!response) {
        console.error("API Error:", response.statusText);
      } else {
        setItemLocalStorage(USER, {
          kidname: formData.kidname,
          selectedDate: formData.selectedDate,
          receiptNo: response.receiptNo,
          endWord: response.endWord,
        });
        navigator("/information");
      }
    } catch (error: any) {
      console.error("Error:", error.message);
    }
  };

  useEffect(() => {
    removeItemLocalStorage(USER);
  }, []);

  return (
    <div className="container-xs mx-auto">
      <div className="w-full h-screen flex flex-col justify-center font-bold">
        <h1 className="text-center text-grey-800 mb-10 text-[2.5rem] font-extrabold tracking-widest">
          상담 정보를 입력하세요
        </h1>
        <FormLayout>
          <TextField
            className="text-end mb-5"
            form={form}
            name="kidname"
            placeholder="이름을 입력해주세요"
            type="text"
            required
            label="이름"
          />
          <div
            className={`border-[0.125rem] border-solid text-2xl rounded-[0.625rem] flex justify-end gap-10 ${
              form.getValues("gender") ? "border-[#2EB500]" : "border-white"
            } w-full bg-white px-6 py-[1.375rem] relative text-end mb-5`}
          >
            <label className="absolute top-[1.375rem] z-10 left-6 text-3xl text-grey-600">
              성별
            </label>

            <label
              className={`cursor-pointer radio-input text-grey-500 ${
                formWatch.gender === "Male" ? "active" : ""
              }`}
            >
              <input
                className="mr-1"
                type="radio"
                value="Male"
                {...form.register("gender")}
                style={{ transform: "scale(1.25)" }}
              />
              남자
            </label>

            <label
              className={`cursor-pointer radio-input text-grey-500 ${
                formWatch.gender === "Female" ? "active" : ""
              }`}
            >
              <input
                className="mr-1"
                type="radio"
                value="Female"
                {...form.register("gender")}
                style={{ transform: "scale(1.25)" }}
              />
              여자
            </label>
          </div>
          <div
            className={`border-[0.125rem] border-solid text-2xl rounded-[0.625rem] ${
              selectedDatecolor === "Green"
                ? "border-[#2EB500]"
                : form.formState.isSubmitted &&
                  form.watch("selectedDate") === null
                ? "border-red"
                : "border-white"
            } w-full bg-white px-6 py-[1.375rem] relative flex justify-end mb-5`}
          >
            <label className="absolute left-6 top-[1.375rem] text-3xl text-grey-600">
              생년월일
            </label>
            <DateInput
              className="cursor-pointer max-w-[13.125rem] text-right mr-2"
              handleDateSelect={handleChangeDateFilter}
            />
          </div>
          <TextField
            className="text-end mb-5"
            form={form}
            name="counselor"
            placeholder="상담기관명을 입력해주세요"
            type="text"
            required
            label="상담기관"
          />
          <TextField
            className="text-end mb-5"
            form={form}
            name="name_counselor"
            placeholder="상담사명을 입력해주세요"
            type="text"
            required
            label="상담사"
          />
          <div className="flex justify-center gap-5 pt-5">
            <SubmitButton
              className="py-4 px-10 text-white text-3xl font-extrabold rounded-[0.625rem] bg-grey-600 focus:outline-none hover:bg-grey-700"
              onClick={handleClear}
            >
              취소
            </SubmitButton>
            <SubmitButton
              className={`py-4 px-10 text-white text-3xl font-extrabold border rounded-[0.625rem] focus:outline-none ${
                checkDisable
                  ? "border-grey-300 bg-grey-300 cursor-not-allowed"
                  : "border-primary bg-primary hover:bg-white hover:text-greenDark"
              }`}
              onClick={form.handleSubmit(handleRegister)}
              disabled={checkDisable}
            >
              확인
            </SubmitButton>
          </div>
        </FormLayout>
      </div>
      <ToastContainer />
    </div>
  );
};

export default InforUser;
