const LoadingInner = () => {
  return <div className="lds-dual-ring"></div>;
};

export default LoadingInner;
