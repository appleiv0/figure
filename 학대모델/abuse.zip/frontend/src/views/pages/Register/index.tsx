import "react-chatbot-kit/build/main.css";
import InforUser from "../../../components/organisms/InfoUser";

const Register = () => {
  return <InforUser />;
};

export default Register;
